//
//  Tela3hoje.swift
//  AquaTrack
//
//  Created by Turma01-8 on 09/10/24.
//

import SwiftUI

struct Aquariosemana: View {
    var body: some View {
        ZStack{
            Color.fundo
                .ignoresSafeArea()
            VStack{
                Text("Aquário").fontWeight(.light)
                    .font(.system(size:38))
                    .foregroundColor(Color.black)
                VStack{
                    HStack{
                        NavigationLink(destination: Aquariohoje()){
                            Text("HOJE")
                            Spacer()
                                .frame(width: 45)
                        }
                        NavigationLink(destination: Aquariosemana()){
                            Text("SEMANA")
                                .foregroundColor(.white)
                                .frame(width: 90, height: 40)
                                .background(Color(.colorsemana))
                                .cornerRadius(23)
                        }
                        Spacer()
                            .frame(width:50)
                            .frame(width:50)
                        NavigationLink(destination: Aquariomes()){
                            Text("MÊS")
                        }
                        
                    }
                    .foregroundColor(.black)
                    .padding()
                    .frame(width: 340, height: 40)
                    .background(Color(.menuu))
                    .cornerRadius(23)
                }
            }
        }
    }
    
    }


#Preview {
    Aquariosemana()
}
