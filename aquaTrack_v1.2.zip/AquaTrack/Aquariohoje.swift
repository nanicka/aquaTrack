//
//  Aquariohoje.swift
//  AquaTrack
//
//  Created by Turma01-8 on 15/10/24.
//

import SwiftUI

struct Aquariohoje: View {
    var body: some View {
        NavigationStack{
        ZStack{
            Color.fundo
                .ignoresSafeArea()
            VStack{
                Text("Aquário").fontWeight(.light)
                    .font(.system(size:38))
                    .foregroundColor(Color.black)

                VStack{
                    HStack{
                        NavigationLink(destination: Aquariohoje()){
                            Text("HOJE")
                                .foregroundColor(.white)
                                .frame(width: 80, height: 40)
                                .background(Color(.menu))
                                .cornerRadius(23)
                            Spacer()
                                .frame(width: 45)
                        }
                        NavigationLink(destination: Aquariosemana()){
                            Text("SEMANA")
                        }
                        Spacer()
                            .frame(width:50)
                            .frame(width:50)
                        NavigationLink(destination: Aquariomes()){
                            Text("MÊS")
                        }
                        
                    }
                    .foregroundColor(.black)
                    .padding()
                    .frame(width: 340, height: 40)
                    .background(Color(.menuu))
                    .cornerRadius(23)
                    
                    HStack{
                        Text("Oxigênio")
                            .offset(x:0 , y:-50)
                            .foregroundColor(.black)
                            .frame(width: 140, height: 140)
                            .cornerRadius(20)
                            .background()
                            .cornerRadius(20)
                        VStack{
                            Text("PH")
                                .offset(x: -60, y: -10)
                                .foregroundColor(.black)
                                .frame(width: 170, height: 60)
                                .cornerRadius(20)
                                .background()
                                .cornerRadius(10)
                                .padding(.bottom,3)
                            
                            Text("Temp.")
                                .offset(x: -50, y: -10)
                                .foregroundColor(.black)
                                .frame(width: 170, height: 60)
                                .cornerRadius(20)
                                .background()
                                .cornerRadius(10)
                        }
                    }
                    Text("Amônia")
                        .offset(x: -110, y: -50)
                        .foregroundColor(.black)
                        .frame(width: 310, height: 140)
                        .cornerRadius(20)
                        .background()
                        .cornerRadius(20)
                    HStack{
                        Text("Nitratos")
                            .offset(x:0 , y:-50 )
                            .foregroundColor(.black)
                            .frame(width: 150, height: 150)
                            .cornerRadius(20)
                            .background()
                            .cornerRadius(20)
                        
                        Text("Nitritos")
                            .offset(x:0 , y:-50 )
                            .foregroundColor(.black)
                            .frame(width: 150, height: 150)
                            .cornerRadius(20)
                            .background()
                            .cornerRadius(20)
                        
                    }.padding(.top, 2.0)
                    
                   
                    
                }
                
            }
            

            
            }
            
        }
            
            
            
        }
        
    }
    
    
       

#Preview {
    Aquariohoje()
}
