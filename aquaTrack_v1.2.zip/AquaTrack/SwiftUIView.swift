//
//  SwiftUIView.swift
//  AquaTrack
//
//  Created by Turma01-8 on 10/10/24.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text("Oi")
    }
}

#Preview {
    SwiftUIView()
}
