//
//  ContentView.swift
//  AquaTrack
//
//  Created by Turma01-22 on 09/10/24.
//

import SwiftUI

struct Tab: View {
    var body: some View {
        VStack{
            TabView{
                Home()
                    .tabItem {
                        Label( "", systemImage: "house.fill")
                    }

                Aquariohoje()
                    .tabItem {
                        Label( "", systemImage: "chart.bar.xaxis")
                    }
                
                config()
                    .tabItem {
                        Label( "", systemImage: "gearshape")
                    }
                
            }
            
        }
    }
}
        
#Preview {
    Tab()
}
