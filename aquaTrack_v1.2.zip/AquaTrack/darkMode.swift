//
//  darkMode.swift
//  AquaTrack
//
//  Created by Turma01-8 on 15/10/24.
//

import SwiftUI

class darkMode: ObservableObject{
    
    @Published var isDarkMode: Bool = false
    
}

