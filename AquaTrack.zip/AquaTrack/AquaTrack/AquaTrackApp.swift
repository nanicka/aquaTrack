//
//  AquaTrackApp.swift
//  AquaTrack
//
//  Created by Turma01-22 on 09/10/24.
//

import SwiftUI

@main
struct AquaTrackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
