//
//  ContentView.swift
//  AquaTrack
//
//  Created by Turma01-22 on 09/10/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        ZStack{
            
            Rectangle()
                .fill(Color.background)
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: .infinity)
                .ignoresSafeArea()
                
            
            VStack {
                Image(.logo)
                    .resizable()
                    .frame(width: 250, height: 230)
                    .scaledToFit()
                    
                
                Spacer()
                
                ZStack{
                    
                    Image(.onda1)
                        .resizable()
                        .frame(width: 420, height: 310)
                    //                    .scaledToFit()
                    
                    Image(.botão)
                        .resizable()
                        .frame(width: 250, height: 70)
                        
                    
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
