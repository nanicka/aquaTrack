import UIKit

struct Mensagem : Encodable {
    let pacote : Int?
}

let url = URL(string: "http://10.87.154.241:1880/testepost")!

var request = URLRequest(url: url)
request.setValue(
"application/json",
forHTTPHeaderField: "Content-Type"
)

request.httpMethod = "POST"

let mensagem = Mensagem(pacote: 1)

let dados = try! JSONEncoder().encode(mensagem)

request.httpBody = dados

let task = URLSession.shared.dataTask(with: request) { dados, resposta, erro in
let statusCode = (resposta as! HTTPURLResponse).statusCode

if statusCode == 200 {
    print("Sucesso")
} else {
    print("Falha")
}

}

task.resume()
