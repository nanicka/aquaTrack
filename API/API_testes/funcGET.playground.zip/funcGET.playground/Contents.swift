import UIKit

struct Pacote : Decodable {
    let _id : String
    let valores : Valores
    let tempo : Int?
}

struct Valores : Decodable {
    let nitrato : Float?
    let nitrito : Float?
    let ph : Float?
    let oxigenio : Float?
    let temperatura : Float?
    let amonia : Float?
}

let url = URL(string: "http://10.87.154.241:1880/testeget")!

var request = URLRequest(url: url)

request.setValue(
    "application/json",
    forHTTPHeaderField: "Content-Type"
)

let task = URLSession.shared.dataTask(with: url) { dados, resposta, erro in
    if let dados = dados {
        if let valores = try? JSONDecoder().decode([Pacote].self, from: dados) {
            print(valores)
        } else {
            print("Resposta inválida")
        }
    } else if let erro = erro {
        print("Pedido HTTP Falhou \(erro)")
    }
}

task.resume()
