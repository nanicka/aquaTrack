//
//  Tela2op.swift
//  AquaTrack
//
//  Created by Turma01-8 on 09/10/24.
//

import SwiftUI

struct Tela2op: View {
var body: some View {
    ZStack{
        Color(.gray)
        VStack{
            HStack{
                Rectangle()
                    .frame(width: 130.0, height: 100.0)
                
                Rectangle()
                    .frame(width: 130.0, height: 100.0)
                    
            }
            }
        }
    }
}

#Preview {
    Tela2op()
}
