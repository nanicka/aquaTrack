//
//  Telasemana.swift
//  AquaTrack
//
//  Created by Turma01-8 on 10/10/24.
//

import SwiftUI

struct Aquariomes: View {
    var body: some View {
       Text("Aquario mês")
    }
}

#Preview {
    Aquariomes()
}
